<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Database Backup Settings')); ?>

            </h2>
            <div class="flex space-x-4">
                <form action="<?php echo e(route('settings.backup.create')); ?>" method="POST" class="inline-block">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <button type="submit" class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-md transition-colors duration-150 ease-in-out shadow-sm">
                        <i class="fas fa-database mr-2"></i>
                        <?php echo e(__('Create New Backup')); ?>

                    </button>
                </form>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <!-- Status Messages -->
            <?php echo $__env->make('layouts.messages', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- Main Content -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <!-- Quick Stats -->
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                        <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                            <div class="text-blue-600 text-sm font-medium uppercase tracking-wide mb-1">Total Backups</div>
                            <div class="text-2xl font-bold text-blue-800"><?php echo e(count($backups)); ?></div>
                        </div>
                        <?php if(count($backups) > 0): ?>
                        <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                            <div class="text-green-600 text-sm font-medium uppercase tracking-wide mb-1">Latest Backup</div>
                            <div class="text-2xl font-bold text-green-800"><?php echo e(date('Y-m-d H:i', $backups[0]['created_at'])); ?></div>
                        </div>
                        <div class="bg-purple-50 border border-purple-200 rounded-lg p-4">
                            <div class="text-purple-600 text-sm font-medium uppercase tracking-wide mb-1">Total Size</div>
                            <div class="text-2xl font-bold text-purple-800">
                                <?php
                                    $totalSize = array_reduce($backups, function($carry, $backup) {
                                        return $carry + $backup['size'];
                                    }, 0);
                                    echo $totalSize > 1024 * 1024 
                                        ? round($totalSize / (1024 * 1024), 2) . ' MB'
                                        : round($totalSize / 1024, 2) . ' KB';
                                ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Backup Information -->
                    <div class="mb-6">
                        <h3 class="text-lg font-medium text-gray-900 mb-2">Backup Management</h3>
                        <p class="text-sm text-gray-600 mb-4">
                            Database backups are essential for data protection. Regular backups help prevent data loss in case of system failures or other issues.
                            Create, download, and manage your backups below.
                        </p>
                    </div>

                    
                    <?php if(isset($debug)): ?>
                    <div class="mb-6 p-4 bg-gray-50 rounded-lg">
                        <h3 class="text-lg font-medium text-gray-900 mb-2">Debug Information</h3>
                        <div class="text-sm text-gray-600">
                            <p><strong>Backup Path:</strong> <?php echo e($debug['backup_path']); ?></p>
                            <p><strong>Backup Count:</strong> <?php echo e($debug['backup_count']); ?></p>
                            <p><strong>Directory Exists:</strong> <?php echo e($debug['directory_exists'] ? 'Yes' : 'No'); ?></p>
                            <p><strong>Directory Writable:</strong> <?php echo e($debug['directory_writable'] ? 'Yes' : 'No'); ?></p>
                            <p><strong>Directory Readable:</strong> <?php echo e($debug['directory_readable'] ? 'Yes' : 'No'); ?></p>
                            <p><strong>Directory Permissions:</strong> <?php echo e($debug['directory_permissions']); ?></p>
                            <p><strong>Found Files:</strong> <?php echo e($debug['found_files']); ?></p>
                            <p><strong>Raw Files:</strong> <?php echo e($debug['raw_files']); ?></p>
                            <p><strong>PHP User:</strong> <?php echo e($debug['php_user']); ?></p>
                            <p><strong>Storage Path:</strong> <?php echo e($debug['storage_path']); ?></p>
                            <p><strong>Public Path:</strong> <?php echo e($debug['public_path']); ?></p>
                            <?php if(isset($debug['error'])): ?>
                            <p class="text-red-600"><strong>Error:</strong> <?php echo e($debug['error']); ?></p>
                            <?php endif; ?>
                            <?php if(isset($debug['trace'])): ?>
                            <pre class="mt-2 p-2 bg-gray-100 rounded text-xs overflow-auto"><?php echo e($debug['trace']); ?></pre>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if(count($backups) > 0): ?>
                        <div class="overflow-x-auto bg-gray-50 rounded-lg border border-gray-200">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-100">
                                    <tr>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Filename</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Size</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Created At</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php $__currentLoopData = $backups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $backup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm font-medium text-gray-900"><?php echo e($backup['filename']); ?></div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm text-gray-500">
                                                    <?php
                                                        $size = $backup['size'];
                                                        if ($size < 1024) {
                                                            echo $size . ' B';
                                                        } elseif ($size < 1024 * 1024) {
                                                            echo round($size / 1024, 2) . ' KB';
                                                        } else {
                                                            echo round($size / (1024 * 1024), 2) . ' MB';
                                                        }
                                                    ?>
                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm text-gray-500">
                                                    <?php echo e(date('Y-m-d H:i:s', $backup['created_at'])); ?>

                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                                <div class="flex justify-end space-x-4">
                                                    <a href="<?php echo e(route('settings.backup.download', $backup['filename'])); ?>" 
                                                       class="inline-flex items-center px-3 py-2 bg-blue-100 text-blue-700 hover:bg-blue-600 hover:text-white rounded-md transition-all duration-150 ease-in-out shadow-sm">
                                                        <i class="fas fa-download mr-2"></i> Download
                                                    </a>
                                                    <form action="<?php echo e(route('settings.backup.destroy', $backup['filename'])); ?>" method="POST" class="inline-block">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" 
                                                                class="inline-flex items-center px-3 py-2 bg-red-100 text-red-700 hover:bg-red-600 hover:text-white rounded-md transition-all duration-150 ease-in-out shadow-sm"
                                                                onclick="return confirm('Are you sure you want to delete this backup? This action cannot be undone.')">
                                                            <i class="fas fa-trash mr-2"></i> Delete
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-12 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
                            <i class="fas fa-database text-4xl text-gray-400 mb-3"></i>
                            <h3 class="text-lg font-medium text-gray-900 mb-2">No Backups Available</h3>
                            <p class="text-sm text-gray-600 mb-4">Create your first database backup to protect your data.</p>
                            <form action="<?php echo e(route('settings.backup.create')); ?>" method="POST" class="inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <button type="submit" class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-md transition-colors duration-150 ease-in-out shadow-sm">
                                    <i class="fas fa-plus mr-2"></i>
                                    <?php echo e(__('Create First Backup')); ?>

                                </button>
                            </form>
                        </div>
                    <?php endif; ?>

                    <div class="mt-8">
                        <h3 class="text-lg font-medium text-gray-900 mb-2">Backup Best Practices</h3>
                        <ul class="list-disc pl-5 text-sm text-gray-600 space-y-1">
                            <li>Create regular backups, especially before major system changes</li>
                            <li>Download and store backups in multiple secure locations</li>
                            <li>Test backup restoration periodically to ensure data integrity</li>
                            <li>Keep at least 3 recent backups at all times</li>
                            <li>Delete old backups to save storage space, but maintain a good retention policy</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/transcript_update/resources/views/settings/backup.blade.php ENDPATH**/ ?>
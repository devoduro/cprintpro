<?php $__env->startSection('title', $parent ? $parent->name : 'Document Categories'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Breadcrumb Navigation -->
    <?php if($parent): ?>
        <nav class="flex" aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-3">
                <li class="inline-flex items-center">
                    <a href="<?php echo e(route('document-categories.index')); ?>" class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600">
                        <i class="fas fa-home mr-2"></i>
                        Categories
                    </a>
                </li>
                <?php $__currentLoopData = $parent->breadcrumbs->slice(0, -1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <div class="flex items-center">
                            <i class="fas fa-chevron-right text-gray-400 mx-2"></i>
                            <a href="<?php echo e(route('document-categories.index', ['parent' => $breadcrumb->id])); ?>" class="text-sm font-medium text-gray-700 hover:text-blue-600">
                                <?php echo e($breadcrumb->name); ?>

                            </a>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li aria-current="page">
                    <div class="flex items-center">
                        <i class="fas fa-chevron-right text-gray-400 mx-2"></i>
                        <span class="text-sm font-medium text-gray-500"><?php echo e($parent->name); ?></span>
                    </div>
                </li>
            </ol>
        </nav>
    <?php endif; ?>

    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
            <h1 class="text-2xl font-bold text-gray-900">
                <?php if($parent): ?>
                    <div class="flex items-center">
                        <div class="p-2 rounded-lg mr-3" style="background-color: <?php echo e($parent->color); ?>20;">
                            <i class="<?php echo e($parent->icon); ?> text-xl" style="color: <?php echo e($parent->color); ?>;"></i>
                        </div>
                        <?php echo e($parent->name); ?>

                        <span class="ml-2 text-sm font-normal text-gray-500">(<?php echo e($parent->isFolder() ? 'Folder' : 'Category'); ?>)</span>
                    </div>
                <?php else: ?>
                    Document Categories
                <?php endif; ?>
            </h1>
            <p class="mt-1 text-sm text-gray-600">
                <?php if($parent): ?>
                    <?php echo e($parent->description ?: 'Manage folders and documents in this ' . ($parent->isFolder() ? 'folder' : 'category')); ?>

                <?php else: ?>
                    Organize your documents into categories for better management
                <?php endif; ?>
            </p>
        </div>
        <div class="mt-4 sm:mt-0 flex space-x-2">
            <?php if($parent): ?>
                <a href="<?php echo e(route('document-categories.create', ['parent' => $parent->id, 'type' => 'folder'])); ?>" class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    <i class="fas fa-folder-plus mr-2"></i>
                    New Folder
                </a>
                <a href="<?php echo e(route('documents.create', ['category' => $parent->id])); ?>" class="inline-flex items-center px-4 py-2 bg-green-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                    <i class="fas fa-file-plus mr-2"></i>
                    Add Document
                </a>
            <?php else: ?>
                <a href="<?php echo e(route('document-categories.create', ['type' => 'category'])); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                    <i class="fas fa-plus mr-2"></i>
                    Create Category
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Categories and Folders Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow cursor-pointer" onclick="window.location='<?php echo e($category->isFolder() ? route('document-categories.index', ['parent' => $category->id]) : route('document-categories.show', $category)); ?>'">
                <!-- Category/Folder Header -->
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center">
                        <div class="p-2 rounded-lg" style="background-color: <?php echo e($category->color); ?>20;">
                            <i class="<?php echo e($category->icon); ?> text-lg" style="color: <?php echo e($category->color); ?>;"></i>
                        </div>
                        <div class="ml-3">
                            <h3 class="text-lg font-medium text-gray-900"><?php echo e($category->name); ?></h3>
                            <div class="flex items-center space-x-2 text-sm text-gray-500">
                                <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium <?php echo e($category->isFolder() ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'); ?>">
                                    <i class="fas <?php echo e($category->isFolder() ? 'fa-folder' : 'fa-layer-group'); ?> mr-1"></i>
                                    <?php echo e($category->isFolder() ? 'Folder' : 'Category'); ?>

                                </span>
                                <span><?php echo e($category->documents_count); ?> documents</span>
                                <?php if($category->children->count() > 0): ?>
                                    <span><?php echo e($category->children->count()); ?> <?php echo e($category->isFolder() ? 'items' : 'folders'); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Status Badge -->
                    <?php if($category->is_active): ?>
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            <i class="fas fa-check-circle mr-1"></i>
                            Active
                        </span>
                    <?php else: ?>
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                            <i class="fas fa-pause-circle mr-1"></i>
                            Inactive
                        </span>
                    <?php endif; ?>
                </div>

                <!-- Description -->
                <?php if($category->description): ?>
                    <p class="text-sm text-gray-600 mb-4"><?php echo e(Str::limit($category->description, 100)); ?></p>
                <?php endif; ?>

                <!-- Path Information -->
                <?php if($category->path && $category->depth > 0): ?>
                    <div class="mb-4 p-2 bg-gray-50 rounded text-xs text-gray-500">
                        <i class="fas fa-route mr-1"></i>
                        Path: <?php echo e($category->path); ?>

                    </div>
                <?php endif; ?>

                <!-- Actions -->
                <div class="flex items-center justify-between pt-4 border-t border-gray-100" onclick="event.stopPropagation()">
                    <div class="flex space-x-2">
                        <?php if($category->isFolder()): ?>
                            <a href="<?php echo e(route('document-categories.index', ['parent' => $category->id])); ?>" class="text-blue-600 hover:text-blue-700 text-sm font-medium">
                                <i class="fas fa-folder-open mr-1"></i>
                                Open
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('document-categories.show', $category)); ?>" class="text-blue-600 hover:text-blue-700 text-sm font-medium">
                                <i class="fas fa-eye mr-1"></i>
                                View
                            </a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('document-categories.edit', $category)); ?>" class="text-indigo-600 hover:text-indigo-700 text-sm font-medium">
                            <i class="fas fa-edit mr-1"></i>
                            Edit
                        </a>
                    </div>
                    
                    <div class="flex space-x-2">
                        <!-- Toggle Status -->
                        <form action="<?php echo e(route('document-categories.toggle-status', $category)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="text-sm font-medium <?php echo e($category->is_active ? 'text-orange-600 hover:text-orange-700' : 'text-green-600 hover:text-green-700'); ?>">
                                <?php echo e($category->is_active ? 'Deactivate' : 'Activate'); ?>

                            </button>
                        </form>
                        
                        <!-- Delete -->
                        <?php if($category->documents_count == 0): ?>
                            <form action="<?php echo e(route('document-categories.destroy', $category)); ?>" method="POST" class="inline" onsubmit="return confirm('Are you sure you want to delete this category?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:text-red-700 text-sm font-medium">
                                    Delete
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full">
                <div class="text-center py-12">
                    <i class="fas fa-folder-open text-4xl text-gray-400 mb-4"></i>
                    <h3 class="text-lg font-medium text-gray-900 mb-2">No categories yet</h3>
                    <p class="text-gray-600 mb-4">Get started by creating your first document category.</p>
                    <a href="<?php echo e(route('document-categories.create')); ?>" class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700">
                        <i class="fas fa-plus mr-2"></i>
                        Create Category
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <?php if($categories->hasPages()): ?>
        <div class="mt-6">
            <?php echo e($categories->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\cprintpro\resources\views/document-categories/index.blade.php ENDPATH**/ ?>
<?php echo e($slot); ?>

<?php /**PATH /home/slceedugh/portal.slce.edu.gh/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>
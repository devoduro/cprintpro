<?php $__env->startSection('title', 'Institution Profile'); ?>
<?php $__env->startSection('subtitle', 'Update institution details, logo, and contact information'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-lg shadow-sm p-6">
    <div class="mb-6">
        <h2 class="text-xl font-bold text-gray-800 mb-2">Institution Profile</h2>
        <p class="text-gray-600">Update your institution's details, logo, and contact information.</p>
    </div>

    <?php if(session('success')): ?>
        <div class="mb-4 p-4 bg-green-50 border-l-4 border-green-500 text-green-700">
            <div class="flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm"><?php echo e(session('success')); ?></p>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('settings.institution.update')); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Basic Information -->
            <div class="space-y-4 col-span-1 md:col-span-2">
                <h3 class="text-lg font-medium text-gray-900">Basic Information</h3>
                
                <div>
                    <label for="institution_name" class="block text-sm font-medium text-gray-700 mb-1">Institution Name*</label>
                    <input type="text" name="institution_name" id="institution_name" value="<?php echo e($settings->where('key', 'institution_name')->first()->value ?? old('institution_name')); ?>" class="w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-500 focus:ring-opacity-50" required>
                    <?php $__errorArgs = ['institution_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div>
                    <label for="institution_slogan" class="block text-sm font-medium text-gray-700 mb-1">Slogan/Motto</label>
                    <input type="text" name="institution_slogan" id="institution_slogan" value="<?php echo e($settings->where('key', 'institution_slogan')->first()->value ?? old('institution_slogan')); ?>" class="w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-500 focus:ring-opacity-50">
                </div>
            </div>
            
            <!-- Logo -->
            <div class="space-y-4 col-span-1 md:col-span-2">
                <h3 class="text-lg font-medium text-gray-900">Institution Logo</h3>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="institution_logo" class="block text-sm font-medium text-gray-700 mb-1">Upload Logo</label>
                        <input type="file" name="institution_logo" id="institution_logo" class="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary-50 file:text-primary-700 hover:file:bg-primary-100">
                        <p class="mt-1 text-xs text-gray-500">Recommended size: 200x200px. Max 2MB. Formats: JPG, PNG, GIF.</p>
                        <?php $__errorArgs = ['institution_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div>
                        <?php if($settings->where('key', 'institution_logo')->first()): ?>
                            <div class="flex flex-col items-center">
                                <p class="text-sm font-medium text-gray-700 mb-2">Current Logo</p>
                                <img src="<?php echo e(asset($settings->where('key', 'institution_logo')->first()->value)); ?>" alt="Institution Logo" class="max-h-24 border border-gray-200 rounded">
                            </div>
                        <?php else: ?>
                            <div class="flex flex-col items-center">
                                <p class="text-sm font-medium text-gray-700 mb-2">No Logo Uploaded</p>
                                <div class="w-24 h-24 bg-gray-100 rounded flex items-center justify-center">
                                    <i class="fas fa-university text-gray-400 text-3xl"></i>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Academic Affairs Signature -->
            <div class="space-y-4 col-span-1 md:col-span-2">
                <h3 class="text-lg font-medium text-gray-900">Academic Affairs Signature</h3>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="academic_affairs_signature" class="block text-sm font-medium text-gray-700 mb-1">Upload Signature</label>
                        <input type="file" name="academic_affairs_signature" id="academic_affairs_signature" class="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary-50 file:text-primary-700 hover:file:bg-primary-100">
                        <p class="mt-1 text-xs text-gray-500">Recommended size: 300x100px. Max 2MB. Formats: JPG, PNG</p>
                        <?php $__errorArgs = ['academic_affairs_signature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div>
                        <?php if($settings->where('key', 'academic_affairs_signature')->first()): ?>
                            <div class="flex flex-col items-center">
                                <p class="text-sm font-medium text-gray-700 mb-2">Current Signature</p>
                                <?php
                                    $signature = $settings->where('key', 'academic_affairs_signature')->first();
                                    $path = $signature ? asset('storage/' . $signature->value) : '';
                                ?>
                              
                                <img src="<?php echo e($path); ?>" alt="Academic Affairs Signature" class="max-h-24 border border-gray-200 rounded">
                            </div>
                        <?php else: ?>
                            <div class="flex flex-col items-center">
                                <p class="text-sm font-medium text-gray-700 mb-2">No Signature Uploaded</p>
                                <div class="w-48 h-16 bg-gray-100 rounded flex items-center justify-center">
                                    <i class="fas fa-signature text-gray-400 text-3xl"></i>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Contact Information -->
            <div class="space-y-4 col-span-1 md:col-span-2">
                <h3 class="text-lg font-medium text-gray-900">Contact Information</h3>
                
                <div>
                    <label for="institution_address" class="block text-sm font-medium text-gray-700 mb-1">Address*</label>
                    <textarea name="institution_address" id="institution_address" rows="3" class="w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-500 focus:ring-opacity-50" required><?php echo e($settings->where('key', 'institution_address')->first()->value ?? old('institution_address')); ?></textarea>
                    <?php $__errorArgs = ['institution_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="institution_phone" class="block text-sm font-medium text-gray-700 mb-1">Phone Number*</label>
                        <input type="text" name="institution_phone" id="institution_phone" value="<?php echo e($settings->where('key', 'institution_phone')->first()->value ?? old('institution_phone')); ?>" class="w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-500 focus:ring-opacity-50" required>
                        <?php $__errorArgs = ['institution_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div>
                        <label for="institution_email" class="block text-sm font-medium text-gray-700 mb-1">Email Address*</label>
                        <input type="email" name="institution_email" id="institution_email" value="<?php echo e($settings->where('key', 'institution_email')->first()->value ?? old('institution_email')); ?>" class="w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-500 focus:ring-opacity-50" required>
                        <?php $__errorArgs = ['institution_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="col-span-1 md:col-span-2">
                        <label for="institution_website" class="block text-sm font-medium text-gray-700 mb-1">Website URL</label>
                        <input type="url" name="institution_website" id="institution_website" value="<?php echo e($settings->where('key', 'institution_website')->first()->value ?? old('institution_website')); ?>" class="w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring focus:ring-primary-500 focus:ring-opacity-50" placeholder="https://example.com">
                        <?php $__errorArgs = ['institution_website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="flex justify-end pt-4">
            <button type="submit" class="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                Save Changes
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/slceedugh/portal.slce.edu.gh/resources/views/settings/institution.blade.php ENDPATH**/ ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'type' => 'text',
    'name',
    'id' => null,
    'label' => null,
    'placeholder' => null,
    'value' => null,
    'disabled' => false,
    'required' => false,
    'autofocus' => false,
    'helper' => null,
    'error' => null,
    'leadingIcon' => null,
    'trailingIcon' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'type' => 'text',
    'name',
    'id' => null,
    'label' => null,
    'placeholder' => null,
    'value' => null,
    'disabled' => false,
    'required' => false,
    'autofocus' => false,
    'helper' => null,
    'error' => null,
    'leadingIcon' => null,
    'trailingIcon' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $id = $id ?? $name;
    $hasError = $error || $errors->has($name);
    $inputClasses = 'w-full rounded-lg shadow-sm focus:ring focus:ring-opacity-50 ' . 
                   ($leadingIcon ? 'pl-10 ' : '') . 
                   ($trailingIcon ? 'pr-10 ' : '') . 
                   ($hasError 
                       ? 'border-red-300 text-red-900 placeholder-red-300 focus:border-red-500 focus:ring-red-200' 
                       : 'border-gray-300 focus:border-primary-500 focus:ring-primary-200');
?>

<div <?php echo e($attributes); ?>>
    <?php if($label): ?>
        <label for="<?php echo e($id); ?>" class="block text-sm font-medium text-gray-700 mb-1">
            <?php echo e($label); ?>

            <?php if($required): ?>
                <span class="text-red-500">*</span>
            <?php endif; ?>
        </label>
    <?php endif; ?>
    
    <div class="relative">
        <?php if($leadingIcon): ?>
            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <i class="<?php echo e($leadingIcon); ?> text-gray-400"></i>
            </div>
        <?php endif; ?>
        
        <input
            type="<?php echo e($type); ?>"
            name="<?php echo e($name); ?>"
            id="<?php echo e($id); ?>"
            <?php if($placeholder): ?> placeholder="<?php echo e($placeholder); ?>" <?php endif; ?>
            <?php if($value !== null): ?> value="<?php echo e($value); ?>" <?php endif; ?>
            <?php if($disabled): ?> disabled <?php endif; ?>
            <?php if($required): ?> required <?php endif; ?>
            <?php if($autofocus): ?> autofocus <?php endif; ?>
            <?php echo e($attributes->merge(['class' => $inputClasses])); ?>

        />
        
        <?php if($trailingIcon): ?>
            <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <i class="<?php echo e($trailingIcon); ?> text-gray-400"></i>
            </div>
        <?php endif; ?>
    </div>
    
    <?php if($helper && !$hasError): ?>
        <p class="mt-1 text-sm text-gray-500"><?php echo e($helper); ?></p>
    <?php endif; ?>
    
    <?php if($error): ?>
        <p class="mt-1 text-sm text-red-600"><?php echo e($error); ?></p>
    <?php elseif($errors->has($name)): ?>
        <p class="mt-1 text-sm text-red-600"><?php echo e($errors->first($name)); ?></p>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\cprintpro\resources\views/components/input.blade.php ENDPATH**/ ?>
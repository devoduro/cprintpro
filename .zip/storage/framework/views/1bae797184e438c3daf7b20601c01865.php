<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('My Profile')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <div class="flex flex-col md:flex-row">
                        <!-- Profile Photo and Basic Info -->
                        <div class="md:w-1/3 flex flex-col items-center md:border-r md:pr-6">
                            <div class="w-32 h-32 rounded-full overflow-hidden mb-4">
                                <?php if($user->profile_photo): ?>
                                    <img src="<?php echo e(asset('storage/' . $user->profile_photo)); ?>" alt="<?php echo e($user->name); ?>" class="w-full h-full object-cover">
                                <?php else: ?>
                                    <div class="w-full h-full flex items-center justify-center bg-gray-100 text-gray-300">
                                        <svg class="w-20 h-20" fill="currentColor" viewBox="0 0 24 24">
                                            <path d="M24 20.993V24H0v-2.996A14.977 14.977 0 0112.004 15c4.904 0 9.26 2.354 11.996 5.993zM16.002 8.999a4 4 0 11-8 0 4 4 0 018 0z" />
                                        </svg>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <h3 class="text-xl font-bold text-gray-900 mb-1"><?php echo e($user->name); ?></h3>
                            <p class="text-sm text-gray-500 mb-2"><?php echo e($user->email); ?></p>
                            <div class="flex items-center mb-4">
                                <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                    <?php echo e(ucfirst($user->role)); ?>

                                </span>
                            </div>
                        </div>

                        <!-- Profile Details -->
                        <div class="md:w-2/3 md:pl-6 mt-6 md:mt-0">
                            <div class="space-y-6">
                                <?php if($user->role === 'student' && $user->student): ?>
                                    <div>
                                        <h4 class="text-lg font-medium text-gray-900 mb-2">Student Information</h4>
                                        <dl class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                            <div>
                                                <dt class="text-sm font-medium text-gray-500">Index Number</dt>
                                                <dd class="mt-1 text-sm text-gray-900"><?php echo e($user->student->index_number); ?></dd>
                                            </div>
                                            <div>
                                                <dt class="text-sm font-medium text-gray-500">Programme</dt>
                                                <dd class="mt-1 text-sm text-gray-900"><?php echo e($user->student->programme->name ?? 'N/A'); ?></dd>
                                            </div>
                                            <div>
                                                <dt class="text-sm font-medium text-gray-500">Current CGPA</dt>
                                                <dd class="mt-1 text-sm text-gray-900"><?php echo e(number_format($user->student->calculateCGPA(), 2)); ?></dd>
                                            </div>
                                            <div>
                                                <dt class="text-sm font-medium text-gray-500">Classification</dt>
                                                <dd class="mt-1 text-sm text-gray-900"><?php echo e($user->student->getClassification() ?? 'N/A'); ?></dd>
                                            </div>
                                        </dl>
                                    </div>
                                <?php endif; ?>

                                <div class="flex items-center justify-end mt-6">
                                    <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['href' => ''.e(route('users.edit', $user)).'','icon' => 'fas fa-edit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('users.edit', $user)).'','icon' => 'fas fa-edit']); ?>
                                        <?php echo e(__('Edit Profile')); ?>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH /home/slceedugh/portal.slce.edu.gh/resources/views/users/profile.blade.php ENDPATH**/ ?>
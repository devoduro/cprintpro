<?php

return [
    // General
    'Cancel' => 'Cancel',
    'Back to Courses' => 'Back to Courses',
    
    // Course related
    'Create Course' => 'Create Course',
    'Update Course' => 'Update Course',
    'Edit Course' => 'Edit Course',
    'Add Course' => 'Add Course',
];
